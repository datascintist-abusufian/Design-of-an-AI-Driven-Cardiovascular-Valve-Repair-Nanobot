import Plotly from 'plotly.js-dist';

// [Previous plot code remains unchanged...]

// Statistical Analysis Plots
const statisticsTitle = document.createElement('h2');
statisticsTitle.textContent = 'Figure 8: Statistical Analysis';
document.body.appendChild(statisticsTitle);

const statisticalContainer = document.createElement('div');
statisticalContainer.className = 'figure-container';
document.body.appendChild(statisticalContainer);

// Power Analysis Plot
const powerAnalysisDiv = document.createElement('div');
powerAnalysisDiv.id = 'power-analysis-plot';
powerAnalysisDiv.className = 'plot';
statisticalContainer.appendChild(powerAnalysisDiv);

const powerAnalysisData = {
    x: [10, 20, 30, 40, 50, 60],
    y: [0.65, 0.78, 0.85, 0.90, 0.94, 0.96],
    type: 'scatter',
    mode: 'lines+markers',
    name: 'Power Analysis',
    line: {
        color: '#2ecc71',
        width: 2
    },
    marker: {
        size: 8,
        color: '#27ae60'
    }
};

const powerAnalysisLayout = {
    title: '(a) Statistical Power Analysis',
    xaxis: {
        title: 'Sample Size (n)',
        range: [0, 70],
        tickmode: 'linear',
        tick0: 0,
        dtick: 10
    },
    yaxis: {
        title: 'Statistical Power (1-β)',
        range: [0.6, 1.0],
        tickformat: '.2f'
    },
    showlegend: false,
    margin: { t: 40, r: 40, l: 60, b: 60 }
};

Plotly.newPlot('power-analysis-plot', [powerAnalysisData], powerAnalysisLayout);

// Confidence Intervals Plot
const ciDiv = document.createElement('div');
ciDiv.id = 'ci-plot';
ciDiv.className = 'plot';
statisticalContainer.appendChild(ciDiv);

const ciData = {
    x: ['Navigation', 'Detection', 'Repair'],
    y: [92, 95, 89],
    error_y: {
        type: 'data',
        array: [2.1, 1.8, 2.5],
        visible: true,
        color: '#e74c3c',
        thickness: 1.5,
        width: 3
    },
    type: 'bar',
    marker: {
        color: ['#3498db', '#2ecc71', '#9b59b6'],
        line: {
            color: '#2c3e50',
            width: 1.5
        }
    }
};

const ciLayout = {
    title: '(b) 95% Confidence Intervals for Key Metrics',
    yaxis: {
        title: 'Success Rate (%)',
        range: [80, 100],
        tickmode: 'linear',
        tick0: 80,
        dtick: 5
    },
    showlegend: false,
    margin: { t: 40, r: 40, l: 60, b: 60 }
};

Plotly.newPlot('ci-plot', [ciData], ciLayout);

// Add caption
const caption = document.createElement('p');
caption.className = 'caption';
caption.innerHTML = `
    <strong>Figure 8.</strong> Statistical analysis of nanobot performance. 
    (a) Power analysis showing the relationship between sample size and statistical power (α = 0.05, β = 0.20). 
    (b) Success rates with 95% confidence intervals for navigation efficiency (92% ± 2.1%), 
    biomarker detection (95% ± 1.8%), and repair accuracy (89% ± 2.5%).
`;
document.body.appendChild(caption);