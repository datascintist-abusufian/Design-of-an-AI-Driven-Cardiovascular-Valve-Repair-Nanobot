---
theme: seriph
background: https://source.unsplash.com/collection/94734566/1920x1080
highlighter: shiki
lineNumbers: false
info: |
  A Novel Framework for Equitable and Explainable 
  Cardiovascular Risk Prediction
drawings:
  persist: false
css: unocss
---

# My Research Journey in Healthcare AI

<div class="grid grid-cols-2 gap-4 mt-8">
<div>
<v-clicks>

## My Path to Research
- Fascinated by AI's potential in healthcare
- Witnessed healthcare disparities firsthand
- Driven to make AI more equitable
- Passionate about explainable AI

## Research Experience
- Led healthcare AI projects
- Published in top venues
- Collaborated with clinicians
- Developed ML solutions

</v-clicks>
</div>

<div>
<v-clicks>

## Why This Research?
- AI can transform healthcare delivery
- Current models lack fairness
- Need for interpretable solutions
- Passion for clinical impact

## Research Goals
- Develop equitable AI models
- Bridge theory-practice gap
- Improve patient outcomes
- Advance healthcare AI field

</v-clicks>
</div>
</div>

<div class="absolute bottom-10">
<em class="text-sm opacity-75">Navigate with arrow keys or space bar</em>
</div>

---
[Rest of the slides remain unchanged...]